/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import java.awt.Color;
import javax.faces.component.UIColumn;
import javax.faces.context.FacesContextWrapper;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pages.SpriteController.ColorConverter;

/**
 *Class used for Unit testing our Color Converter
 * @author Kevin Lai, John Dobie, Seongyeop Jeong
 */
public class TestColorConverter {
    
    public TestColorConverter() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

     
    
     @Test
     public void testColorConverter() {
     ColorConverter converter = new ColorConverter();
     
     Color colorObject;
     // Get a color object from calling getAsObject() method and passing a string representation of a Color.
     colorObject = (Color) converter.getAsObject(new FacesContextWrapper(){}, new UIColumn(), "Red:1, Green:2, Blue:3");
     
     assertEquals(colorObject,new Color(1,2,3)); // test will pass
     }
     
     @Test public void testColorConverterString() {
         ColorConverter converter = new ColorConverter();
  
         Color colorObject = new Color(1,2,3);
         
         String colorString;
         // Get a string representatation of a color by calling getAsString() method and passing in a Color Object
         colorString = converter.getAsString(new FacesContextWrapper(){}, new UIColumn(),colorObject);
         
         assertEquals(colorString,"Red:1, Green:2, Blue:3"); // test will pass
         
     }
}

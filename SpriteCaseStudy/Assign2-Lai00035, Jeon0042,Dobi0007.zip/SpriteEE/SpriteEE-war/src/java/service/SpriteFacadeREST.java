/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import business.Sprite;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author mykar
 */
@Stateless
@Path("business.sprite")
public class SpriteFacadeREST extends AbstractFacade<Sprite> {

    @PersistenceContext(unitName = "SpriteEE-warPU")
    private EntityManager em;

    public SpriteFacadeREST() {
        super(Sprite.class);
    }
   
    /*
        POST on a specific id should update the Sprite having that id with the new non-null information given by the Sprite in the body of the request (response 200 - ok)
	-It’s an error if the id doesn’t exist(response 404 - not found), or if the Sprite in the body has a non-matching id (response 400 - bad request)
    */
    @POST
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response modifyResource(@PathParam("id") Long id, Sprite entity) throws Exception {
        
        // checks to see if specific id and id in the body request have been specified by user
        if( id == null || entity.getId() == null) {
            return Response.status(Response.Status.BAD_REQUEST).entity("id was not specified").build();
        }
        // checks to see if id in the field and body are mismatched
        else if(id.longValue() != entity.getId().longValue()) {
            return Response.status(Response.Status.BAD_REQUEST).entity("id is mismatched").build();
        }
        else {
            Sprite temp = super.find(entity.getId());
            if(temp == null || super.find(id) == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Sprite was not found in database").build();
            }
            else {
                entity.modify(temp);         
                super.edit(temp);
            }
        }
        return Response.status(Response.Status.OK).entity(super.find(entity.getId())).build();
    }
    
    /*
    	POST on the root resource (sprite table) 
	- Accepts a Sprite in the body of the request
	- Creates the new sprite if id is null (response 201 - created)
	- Updates an existing sprite if id is not null and exists (response 200 - ok)
	- Throws an exception if the id is not null and does not exist (response 400 - not found)
    */
    @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response modifyRoot(Sprite entity) throws Exception {
        if(entity.getId() == null) {
            entity.checkForNull(entity);
             super.create(entity);
             return Response.status(Response.Status.CREATED).entity(super.find(entity.getId())).build();
             
        }
        else {
            Sprite temp = super.find(entity.getId());
            if(temp == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Sprite was not found in database").build();
            }
            else {
                entity.modify(temp);
                super.edit(temp);
            }
        }
        return Response.status(Response.Status.OK).entity(super.find(entity.getId())).build();
    }
    
      
    /*
    PUT on Root Resource is not support and we deal with that by returning (response 501 - not implemented) with an message to indicate that its not supported.
    */
    @PUT
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response editRoot(Sprite entity) throws Exception {
            return Response.status(Response.Status.NOT_IMPLEMENTED).entity("PUT on root resource is not supported").build();
    }
    
    /*
    	PUT on a specific id should replace the Sprite having that id with the Sprite in the body of the request. (response 200 - ok)
	- It’s an error if the id doesn’t exist(response 404 - not found), or if the Sprite in the body has a non-matching id (response 400 - bad request)

    */
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
     @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response edit(@PathParam("id") Long id, Sprite entity) throws Exception {
       
              
        if(id == null || entity.getId() == null) {
            return Response.status(Response.Status.BAD_REQUEST).entity("id was not specified").build();
        }
        else if(id.longValue() != entity.getId().longValue()) {
            return Response.status(Response.Status.BAD_REQUEST).entity("id is mismatched").build();
        } 
        else {
            Sprite temp = super.find(entity.getId());
            if(temp == null || super.find(id) == null) {
               return Response.status(Response.Status.NOT_FOUND).entity("Sprite was not found in database").build();
            }
            else {
                entity.checkForNull(entity);
                super.edit(entity);
            }
        }   
       return Response.status(Response.Status.OK).entity(super.find(entity.getId())).build(); 
    }

    /*
    Check for specific id of Sprite to delete and removes from database (response 200 - ok)
    - it is an error if Sprite is not found in the database(response 404 - not found)
    */
    @DELETE
    @Path("{id}")
    public Response remove(@PathParam("id") Long id) {
        Sprite sprite = super.find(id);
        if(sprite == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("Sprite to delete was not found in database").build();
        }
        else {
            super.remove(super.find(id));
          return Response.status(Response.Status.OK).entity("Sprite with Id:"+id.longValue()+" has been sucessfully removed").build();
        }
    }

    /*
    Fetches the specific id of a Sprite from the database (response 200 - ok)
    - it is an error if Sprite is not found in the database(response 404 - not found)
    */
    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response find(@PathParam("id") Long id) {
        Sprite sprite = super.find(id);
        if(sprite == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("Sprite was not found in database").build();
           }
        else{
        return Response.status(Response.Status.OK).entity(sprite).build(); 
        }
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}

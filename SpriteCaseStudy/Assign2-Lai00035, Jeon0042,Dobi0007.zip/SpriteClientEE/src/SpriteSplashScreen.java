import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JWindow;

public class SpriteSplashScreen extends JWindow {
  private static final long serialVersionUID = 1L;
  private final int timeSplash;
  
  public SpriteSplashScreen(int timeSplash) {
    this.timeSplash = timeSplash;
  }
  
  public void showSplashWindow() {
    // declare the JPanel to assign the window 
    JPanel mainPanel = new JPanel(new BorderLayout());
    // set the window size
    int width = 500;
    int height = 255;
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (screen.width - width) / 2;
    int y = (screen.height - height) / 2;
    // set the location and the size of the window
    setBounds(x, y, width, height);
    // to create the splash screen with labels 
    JLabel label = new JLabel(new ImageIcon(getClass().getResource("splash.gif")));
    JLabel demo = new JLabel("Assignment2 Sprite Case Study", JLabel.CENTER);
    // set the font style 
    demo.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
    // set the color of the text
    demo.setForeground(Color.white);
    // create custom RGB color
    mainPanel.setBackground(new Color(38, 38, 38));
    mainPanel.setBorder(BorderFactory.createLineBorder(Color.gray, 10));
    // add the labels to the main panel
    mainPanel.add(label, BorderLayout.CENTER);
    mainPanel.add(demo, BorderLayout.SOUTH);
    setContentPane(mainPanel); // set the content pane for this application's window
    setVisible(true); // to set up the visibility of the splash window
    // While the application is loading, throw the exceptions if the application is interrupted   
    try {
      Thread.sleep(timeSplash);
    } catch (InterruptedException e) {
      // thrown the thread when the application is interrupted
    }
    dispose(); // release the all of the resources of the window
  }
}
